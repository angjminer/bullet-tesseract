// This is a modified movable.cpp: implements physics for inanimate models
// it should be a good breakout for our bullet ents
#include "game.h"
#include "engine.h"

extern int physsteps;

namespace game
{
    enum
    {
        BULLETWEIGHT = 25,
        BULLETHEALTH = 5,
        BARRELWEIGHT = 25,
        PLATFORMWEIGHT = 1000,
        PLATFORMSPEED = 8,
        EXPLODEDELAY = 200
    };

    struct bulletmovable : dynent
    {
        int etype, mapmodel, health, weight, exploding, tag, dir;
        physent *stacked;
        vec stackpos;

        bulletmovable(const entity &e) : 
            etype(e.type),
            mapmodel(e.attr2),
            health(e.type==BARREL ? (e.attr4 ? e.attr4 : BULLETHEALTH) : 0), 
            weight(e.type==PLATFORM || e.type==ELEVATOR ? PLATFORMWEIGHT : (e.attr3 ? e.attr3 : (e.type==BARREL ? BARRELWEIGHT : BULLETWEIGHT))), 
            exploding(0),
            tag(e.type==PLATFORM || e.type==ELEVATOR ? e.attr3 : 0),
            dir(e.type==PLATFORM || e.type==ELEVATOR ? (e.attr4 < 0 ? -1 : 1) : 0),
            stacked(NULL),
            stackpos(0, 0, 0)
        {
            state = CS_ALIVE;
            type = ENT_BULLETENT;
            yaw = e.attr1;
            //if(e.type==PLATFORM || e.type==ELEVATOR) 
            //{
                //maxspeed = e.attr4 ? fabs(float(e.attr4)) : PLATFORMSPEED;
                //if(tag) vel = vec(0, 0, 0);
                //else if(e.type==PLATFORM) { vecfromyawpitch(yaw, 0, 1, 0, vel); vel.mul(dir*maxspeed); } 
               // else vel = vec(0, 0, dir*maxspeed);
            //}

            const char *mdlname = mapmodelname(e.attr2);
            if(mdlname) setbbfrommodel(this, mdlname);
        }
       
        void hitpush(int damage, const vec &dir, gameent *actor, int gun)//concern gun
        {
            if(etype!=BULLETENT) return;
            vec push(dir);
            //push.mul(80*damage);///weight);
            push.mul((actor==actor && attacks[gun].exprad ? EXP_SELFPUSH : 1.0f)*attacks[gun].hitpush*damage/weight);
            vel.add(push);

        }

        void explode(dynent *at)
        {
            state = CS_DEAD;
            exploding = 0;
            //game::explode(true, (gameent *)at, o, this, guns[GUN_BARREL].damage, GUN_BARREL);
        }
 
        void damaged(int damage, gameent *at, int gun = -1)
        {
            if(etype!=BARREL || state!=CS_ALIVE || exploding) return;
            health -= damage*damage;
            if(health>0) return;
            //if(gun==GUN_BARREL) exploding = lastmillis + EXPLODEDELAY;
            else explode(at); 
        }

        void suicide()
        {
            state = CS_DEAD;
            if(etype==BARREL) explode(player1);
        }
    };

    vector<bulletmovable *> bulletmovables;
   
    void clearbulletmovables()
    {
        if(bulletmovables.length())
        {
            cleardynentcache();
            bulletmovables.deletecontents();
        }
        //if(!m_dmsp && !m_classicsp) return;
        loopv(entities::ents) 
        {
            const entity &e = *entities::ents[i];
            if(e.type!=BULLETENT) continue;
            bulletmovable *m = new bulletmovable(e);
            bulletmovables.add(m);
            m->o = e.o;
	    const char *mdlname = mapmodelname(m->mapmodel);
            entinmap(m);
	    setcbfrommodel(m, mdlname);
            updatedynentcache(m);
        }
    }


    void stackbulletmovable(bulletmovable *d, physent *o)
    {
        d->stacked = o;
        d->stackpos = o->o;
    }

    void updatebulletmovables(vec tmpvec,vec tmprot,int j)
    {
        //if(!curtime) return;
        loopv(bulletmovables)
        {
	  //conoutf(");
	  if(i == j-1){

            bulletmovable *m = bulletmovables[i];
            //if(m->state!=CS_ALIVE) break;
	    //0.058825
	    m->o = vec(tmpvec.x*17,tmpvec.z*17,tmpvec.y*17);
	    m->yaw = tmprot.y;
	    m->pitch = -tmprot.x;//correct
	    m->roll = tmprot.z;


	    
	    conoutf("rotation = %f,%f,%f\n",m->pitch,m->roll,m->yaw);
	  }
        }
    }

    void renderbulletmovables()
    {
        loopv(bulletmovables)
        {
            bulletmovable &m = *bulletmovables[i];
            if(m.state!=CS_ALIVE) continue;
            //vec o = m.feetpos();//o must be center of model
            const char *mdlname = mapmodelname(m.mapmodel);
            if(!mdlname) continue;
			rendermodel(mdlname, ANIM_MAPMODEL|ANIM_LOOP, m.o, m.yaw, m.pitch, m.roll, MDL_CULL_VFC | MDL_CULL_DIST | MDL_CULL_OCCLUDED, &m);
        }
    }
    
    void suicidebulletmovable(bulletmovable *m)
    {
        m->suicide();
    }

    void hitbulletmovable(int damage, bulletmovable *m, gameent *at, const vec &vel, int gun)
    {
        m->hitpush(damage, vel, at, gun);
        m->damaged(damage, at, gun);
    }
}